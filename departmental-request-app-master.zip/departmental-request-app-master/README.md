# Departmental Request App

This is the completed app you end up with when you work through the [departmental request tutorial](https://github.com/ServiceNowDevProgram/departmental-request-tutorial)

You can fork this repo and then connect to your forked repo and pull the app into your instance. For detailed instructions on how to do this, check out the [Github Guide](https://developer.servicenow.com/dev.do#!/guides/rome/developer-program/github-guide/github-and-the-developer-site-training-guide-introduction) on the developer site.
